# Clustering - Healthy Life Expectancy (HLE) vs Current Health Expenditure (CHE)

library(tidyverse)

# Load the Healthy Life Expectancy (HLE) dataset
HLE_raw <- readRDS("data/HLE_raw.rds")
HLE_raw %>% dim()

HLE <- HLE_raw %>% 
  filter(Indicator=="Healthy life expectancy (HALE) at birth (years)",
         Dim1=="Both sexes")  %>%  
  select(Location, FactValueNumeric) %>%
  rename(country = Location, hle = FactValueNumeric) 

HLE %>% head()

HLE <- HLE %>%
  mutate(country = recode(country, 
                          "United Arab Emirates" = "UAE",
                          "occupied Palestinian territory, including east Jerusalem" = "Palestine", 
                          "Syrian Arab Republic" = "Syria")) %>%
  group_by(country) %>% 
  reframe(hle=round(mean(hle)))

HLE %>%
  head()


CHE_raw <- readRDS("data/CHE_raw.rds")
CHE_raw %>% dim()

CHE <- CHE_raw %>% 
  filter(Indicator=="Current health expenditure (CHE) as percentage of gross domestic product (GDP) (%)")  %>%  
  select(Location, FactValueNumeric) %>%
  rename(country = Location, che = FactValueNumeric) 
  

CHE %>% head

CHE <- CHE %>% 
  mutate(Country = recode(country, 
                          "United Arab Emirates"="UAE",
                          "occupied Palestinian territory, including east Jerusalem"="Palestine", 
                          "Syrian Arab Republic"="Syria")) %>%
  group_by(country) %>% 
  reframe(che=round(sum(che),3))

CHE %>% head


### Jointed dataframe HLE and CHE


CHEHLE <- merge(x = HLE, y = CHE, by = "country") %>% 
  select(country, hle, che)

CHEHLE %>% head


## Clustering with K-means
      
?kmeans()

A <- CHEHLE[,2:3]

km <- kmeans(A, centers = 5, iter.max = 1000)
CHEHLE$group <- km$cluster

CHEHLE %>% head

set.seed(1111)  # for reproducibility

CHEHLE_sample <- CHEHLE[sample(nrow(CHEHLE), 50) ,]


## Data Visualization


ggplot(CHEHLE_sample %>% 
         mutate(group = as.factor(group)),
       aes(x = hle, y = che, label = country)) +
  geom_text(aes(y = che, x = hle, color = group),
            check_overlap = T,
            size = 3, 
            fontface = "bold",
            show.legend = FALSE)  + 
  scale_color_brewer(palette = "Set1") +
  labs(title = "Healthy life expectancy vs. Current health expenditure",
       x = "Healthy Life Expectancy (years)", 
       y = "Current Health Expenditure (% GDP per cap)") +
  theme_bw() +
  theme(plot.title = element_text(face = "bold", hjust = 0.5, size = 16))



