# Predictive Modeling - Predicting Lives Based on Age and Country

library(tidyverse)
library(lifecontingencies)

# Load the data

data("demoFrance")
data("demoGermany")

# Explore the data

head(demoFrance)
head(demoGermany)

livesFrance <- demoFrance %>%
  select(age, lives = TH00_02)

livesGermany <- demoGermany %>%
  rename(age = x) %>%
  select(age, qx = qxMale) %>%
  mutate(px = 1 - qx,
         lives = c(1, head(lead(px), -1)),
         lives = as.integer(100e3*cumprod(lives))) %>%
  select(age, lives)

# Combine the data

livesData <- livesFrance %>%
  mutate(country = "France") %>%
  bind_rows(livesGermany %>%
              mutate(country = "Germany"))

head(livesData)

# Visualize the data

ggplot(livesData, aes(x = age, y = lives, color = country)) +
  geom_line() +
  labs(title = "Number of Lives by Age and Country",
       x = "Age",
       y = "Number of Lives") +
  theme_minimal()

# Model selection

ggplot(livesData, 
       aes(x = age, y = lives)) +
  geom_line(aes(linetype = country)) +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  geom_smooth(method = "gam", se = FALSE, color = "green") +
  labs(title = "Lives by Age and Country", 
       x = "Age", y = "Lives",
       caption = "Linear (blue) vs. GAM Model (green)")


# Split the data into training and test sets
set.seed(123)
train_index <- sample(1:nrow(livesData), 
                      0.8 * nrow(livesData),
                      replace = FALSE)
train_data <- livesData[train_index, ]
test_data <- livesData[-train_index, ]

# Fit a GAM model

gam_model <- glm(formula = Lives ~ poly(age, 2) + Country, 
                 data = train_data)

summary(gam_model)  

# Make predictions
test_data <- test_data %>%
  mutate(predicted_lives = predict(gam_model, newdata = test_data))

# Evaluate the model

mse <- mean((test_data$lives - test_data$predicted_lives)^2)
rmse <- sqrt(mse)
cat("Root Mean Squared Error (RMSE):", rmse, "\n")

# Visualize the predictions

ggplot(test_data, aes(x = age)) +
  geom_point(aes(y = lives, color = "Actual"), alpha = 0.5) +
  geom_line(aes(y = predicted_lives, color = "Predicted"), size = 1) +
  facet_wrap(~ country) +
  labs(title = "Actual vs Predicted Lives by Age and Country",
       x = "Age",
       y = "Number of Lives",
       color = "Legend") +
  theme_minimal()
