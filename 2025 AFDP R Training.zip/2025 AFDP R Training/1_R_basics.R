# R Basics for Exams

x <- c(10, 20, 30)
mean(x); sd(x)
df <- data.frame(age = c(25, 30), 
                 premium = c(100, 120))

# save as csv
write.csv(df, "data/df.csv", 
          row.names = FALSE)
# read csv
df <- read.csv("data/df.csv")

# subset
df$premium[df$age > 28]

# basic operations
df$premium * 1.1
df$premium + 10

# distributions
# normal distribution
# dnorm(x, mean, sd)

# random normal distribution
my_distr <- rnorm(5, mean = 0, sd = 1)
plot(density(my_distr))
plot(density(rnorm(1000)))

# poisson distribution
# dpois(x, lambda)
dpois(3, lambda = 2) 
ppois(3, lambda = 2)
# install actuar package for Pareto distribution

library(actuar)
actuar::rpareto(5, shape = 2, scale = 100)

