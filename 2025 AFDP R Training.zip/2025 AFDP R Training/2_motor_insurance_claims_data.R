# Data manipulation and visualization for motor insurance claims

library(tidyverse)

readRDS("data/freMTPLfreq_1000.rds") -> freMTPLfreq
readRDS("data/freMTPLsev.rds") -> freMTPLsev

# Data Exploration

glimpse(freMTPLfreq)
glimpse(freMTPLsev)

# Data manipulation
freMTPLfreq <- freMTPLfreq %>%
  mutate(PolicyID = as.integer(PolicyID))

claims_data_raw <- freMTPLfreq %>%
  merge(freMTPLsev, by = "PolicyID")

# Grouping and Summarize total claims by DriverAge
claims_summary <- claims_data_raw %>%
  group_by(DriverAge) %>%
  reframe(TotalClaims = sum(ClaimAmount))

claims_summary

# Filter claims greater than 1000
high_claims <- claims_data_raw %>% 
  filter(ClaimAmount > 1000)

# Data visualization
ggplot(data = high_claims, 
       aes(x = factor(DriverAge), y = ClaimAmount)) +
  geom_col() +
  labs(title = "High Claims by Driver Age",
       x = "Driver Age",
       y = "Claim Amount")


