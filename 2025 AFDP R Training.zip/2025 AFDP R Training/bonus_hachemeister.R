# Hachemeister Data Set

# search for data in the actuar package
data(package = "actuar")
data(hachemeister)
?hachemeister

# Data Manipulation

hachemeister_long <- hachemeister %>%
  as_tibble() %>%
  pivot_longer(
    cols = -state,
    names_to = c(".value", "month"),
    names_pattern = "(ratio|weight)\\.(\\d+)"
  ) %>%
  rename(
    claim_amount = ratio,
    claim_number = weight
  ) %>%
  mutate(
    month = as.integer(month)  # convert to numeric month if needed
  )

hachemeister_long

# Import export
write.csv(hachemeister_long, 
          "data/hachemeister_long.csv", 
          row.names = FALSE)
data <- read.csv("data/hachemeister_long.csv")

# Data Wrangling
data %>%
  filter(claim_amount > 1000) %>%
  group_by(state) %>%
  summarise(avg_claim = mean(claim_amount))

# Data Exploration
ggplot(data, aes(x = state, y = claim_amount, 
                 group = state)) +
  geom_boxplot()

ggplot(data, aes(x = claim_amount)) +
  geom_histogram(bins = 30, fill = "blue", color = "black") +
  scale_x_log10() +
  theme_minimal()

# scatterplot

data %>%
  ggplot(aes(x = month, y = claim_amount)) +
  geom_point(alpha = 0.5) +
  geom_smooth() +
  scale_x_continuous(breaks = 1:12) +
  theme_minimal()

data %>%
  ggplot(aes(x = claim_number, y = claim_amount)) +
  geom_point(alpha = 0.5) +
  geom_smooth() +
  scale_x_log10() +
  scale_y_log10() +
  theme_minimal()

# Modeling claim_number by claim_amount, state, and month
model <- glm(claim_number ~ claim_amount + state + month, 
             data = data, 
             family = poisson(link = "log"))
summary(model)

# Predicting claim_number for a new data point
new_data <- data.frame(
  claim_amount = 1500,
  state = 2,
  month = 6
)

predicted_claims <- predict(model, 
                            newdata = new_data, 
                            type = "response")
predicted_claims
